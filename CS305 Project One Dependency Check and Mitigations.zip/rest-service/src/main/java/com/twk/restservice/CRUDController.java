package com.twk.restservice;

import java.sql.SQLException;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CRUDController {

    @GetMapping("/read")
    public String readDocument(@RequestParam(value = "business_name") String name) {
        DocData dao = new DocData(name);
        try {
            byte[] data = dao.readDocument();
            // TODO: Process document data as needed
            return "Document data successfully retrieved";
        } catch (SQLException e) {
            // TODO: Handle the exception as appropriate
            return "Failed to retrieve document data";
        }
    }

}
